import os

# Get a list of all log files in the Logs directory
# Hint: Use the os.listdir() function

# Process each log file
# Hint: Use a for loop to iterate over the log files

    # Initialize counters for each type of event
    # Hint: You can use simple variables for this

    # Open the log file
    # Hint: Use the 'with open()' statement to open the file for reading

        # Read each line in the log file
        # Hint: Use a for loop to iterate over the lines in the file

            # Count the number of each type of event
            # Hint: Use if statements and the 'in' keyword to check if a string is in the line

    # Write the counts to the report file
    # Hint: Use the 'with open()' statement to open the file for writing
    # Hint: Use the 'write()' method to write a line to the file
